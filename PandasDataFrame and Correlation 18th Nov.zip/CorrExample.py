#create dataframe from dict
import pandas as pd

d ={'ecode':[11,1,2,3,4],
       'name':['Nitin','Raman','Monika','Rahul','Vidhi'],
       'exp':[1,18,3,6,8],
       'age':[21,41,24,22,26],
       'sal':[11000,110000,20000,30000,40000]}


emp = pd.DataFrame(data=d)

print(emp)

'''
Co-relation: how variables are corelated with each other
output range:
 -1 to +1
 -1 : negative corelation
 +1 : pos corelation
 0 : no corelation
 
'''

print(emp.corr())
o = emp.corr()
o.to_csv(r'C:\Users\vkumar15\Desktop\Learning & Training\corr.csv')





