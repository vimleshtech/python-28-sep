import pandas as pd


data= pd.read_csv(r'C:\Users\vkumar15\Desktop\mtcars.csv')
#print(data)

o=data.corr()
print(o)

o.to_csv(r'C:\Users\vkumar15\Desktop\mtcars_corelation.csv')
