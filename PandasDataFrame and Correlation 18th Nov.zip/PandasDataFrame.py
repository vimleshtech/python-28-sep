import pandas as pd


data= pd.read_csv(r'C:\Users\vkumar15\Desktop\Learning & Training\emp.csv')
print(data)
print(data.columns)

#reaname
data.columns = ['ecode','name','gender','sal']
print(data)



#show selected columns
print(data['ecode'])
print(data[['ecode','sal']])


#sort
print(data.sort_values('sal',ascending=True))
print(data.sort_values('sal',ascending=False))
print(data.sort_values('name',ascending=False))



#group or data distribuation
print(data.groupby('gender').count())
print(data.groupby('gender').size())
print(data.groupby('gender').max())
print(data.groupby('gender').min())
print(data.groupby('gender').sum())
print(data.groupby('gender').sum()['sal'])

#info
print(data.info())

#show stats
print(data.describe())



















