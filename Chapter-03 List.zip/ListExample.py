sales = [111,222,34334,555,232,11]

print(max(sales))
print(min(sales))
print(sum(sales))
print(len(sales))


sales.sort()
print(sales)


sales.append(100)
sales.append(200)
print(sales)

print(sales.pop())
print(sales.pop())
print(sales)

sales.insert(1,45)
print(sales)

#error 
sales.remove(45)
print(sales)

if 50 in sales:
    sales.remove(50)
    


sales.remove(saels[1]) #get value for 2nd index



