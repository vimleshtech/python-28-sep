n =1
c =0
for i in range(10):
    
    print(n)
    n = n+4+c
    c = c+2
    
    
    
