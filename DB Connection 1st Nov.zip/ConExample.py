import mysql.connector as con

c = con.connect(host='localhost',user='root',password='root',database='mypython')

cur  = c.cursor()


def get_data():
    cur.execute('select * from emp')

    o = cur.fetchall()

    for r in o:
        print(r[0] , r[2])
    

def save_data():
    cur.execute("insert into emp(eid,name,gender,salary) values({},'{}','{}',{})".format(10,'rahul','male',555666))
    c.commit() #execte and save data


save_data()
get_data()



    
