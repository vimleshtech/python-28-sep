import socket               # Import socket module
import random

s = socket.socket()         # Create a socket object

host = socket.gethostname() # Get local machine name


port = 1234                # Reserve a port for your service.
s.bind((host, port))        # Bind to the port

print('plz wait for connection ')

s.listen(10)                 # Now wait for client connection.
while True:
   a,b = s.accept()     # Establish connection with client.
   print ('Got connection from', b)
   otp = str(random.randint(1000,9999))
   
   
   a.send(otp.encode())
    
   a.close()                # Close the connection
   
