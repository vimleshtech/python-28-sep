import re

d = input('enter data or string :')

#extract data 
print(re.findall('\d',d))


#match
o = re.match('(.*) are (.*)',d)
#print(o.groups())

if o:
    print('are is exist')
else:
    print('are is not exist')



###search
email = input('enter email id:')
o = re.search('@gmail.com$',email)

if o:
    print('valid gmail account')
else:
    print('invalid gmail account')
    
