import time
import threading


def process1():

    for x in range(1,5):
        print(x)
        time.sleep(1)


def process2():
        
    for x in range(11,15):
        print(x)
        time.sleep(1)




#process1()
#process2()

p1= threading.Thread(target=process1,name='p1')
p2= threading.Thread(target=process2,name='p2')




p1.start()
p2.start()
