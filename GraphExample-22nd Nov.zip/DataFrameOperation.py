import pandas as pd

stu = pd.read_csv(r'C:\Users\vkumar15\Desktop\student.csv')

print(stu)

print(type(stu))

#convert dataframe to array/list
s = stu.values
print(s)
print(type(s))

total = []
avg = []
grade = []
for r in s:
    t = r[2]+r[3]+r[4]
    a =t/3
    g =''
    if a>=80:
        g ='A'
    elif a>=60:
        g='B'
    elif a>=40:
        g='C'
    else:
        g='D'
    total.append(t)
    avg.append(a)
    grade.append(g)


stu['total']=total
stu['avg']=avg
stu['grade']=grade

stu.to_csv(r'C:\Users\vkumar15\Desktop\student_out.csv')



















    
    
        
        





