import pandas as pd
import matplotlib.pyplot as plt

stu = pd.read_csv(r'C:\Users\vkumar15\Desktop\student_out.csv')

s = stu[['ms','es','cs','total','avg']]

#default graph type is line chart
#s.plot()
#s.plot(kind='bar')
#s.plot(kind='box')

#s.plot(kind='line',subplots=True)
s.plot(kind='bar',subplots=True,layout=(3,2))
plt.show()




