import pandas as pd

data= pd.read_csv(r'C:\Users\vkumar15\Desktop\emp.csv')

print(data)

#stats : max, min, sum, count, sd , 25% 50%, 75%
print(data.describe())

#
print(data.groupby('gender').size())

                   
                   


