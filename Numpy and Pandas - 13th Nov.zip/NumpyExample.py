import numpy as np


#list operation 
a = [11,33,44,5,66]
print(a*2)

#numpy work with array : single data type , arithmetic operation
d = np.array(a)
print(type(d))
print(d)
print(d*2)


#aragne
m = np.arange(10)
print(m)

m = np.arange(1,10,.5) #init, stop, incrementer 
print(m)

#data type
d = np.array(a,dtype=float)
print(d)

#
x =np.ones(10)
print(x)


x =np.zeros(10)
print(x)


####
a = [[1,2,2],[4,5,6],[6,7,8]]
x = np.array(a)
print(x)

y = x*2

print(y)

print(np.add(x,y))
print(np.multiply(x,y))
print(np.subtract(x,y))
print(np.divide(x,y))


###
y = [11,22,44,5,43,23,2,222]

x = np.array(y).reshape(-1,2)
print(x)



























    
