import pandas as pd

d ={'eid':[1,2,3,4,5],
    'name':['Raman','Jatin','Monika','Divya','Ayush'],
    'gender':['male','male','female','female','male'],
    'sal':[120000,340000,45000,51000,100000]}

#convert/create dict to data frame 
data =pd.DataFrame(data=d) #create empty data frame
print(data)

print(data.columns)

print(data.head(n=2))#reaturn row from top , default count is 5
print(data.tail(n=2))#return from buttom

print(data.shape) #row,col count

print(data.info()) #


#show selected columns
print(data['name'])

print(data[['name','sal']])
print(data[['name','sal','gender']])


#rename column
data.columns = ['eid','name','gender','salary']
print(data)

#add new column in existing data frame
data['age'] = [23,41,51,12,34]
print(data)


#write/save data to file
data.to_csv(r'C:\Users\vkumar15\Desktop\emp.csv',index=False)
print('data is saved')
















