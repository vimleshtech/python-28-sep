n = int(input('enter data :'))
d = int(input('enter data :'))

try:
    
    #div
    if d<0:
        msg = ZeroDivisionError('divisor cannot be negative ')
        raise msg #go to except block 
    o =n/d
    print(o)

except ZeroDivisionError as e:
    #print('there is technical error ,try after some time')
    print(e)    
    pass
except NameError as er:
    print(er)
except:
    print('other types error')

finally :
    print('end of code')
    
#add
o =n+d
print(o)

      
