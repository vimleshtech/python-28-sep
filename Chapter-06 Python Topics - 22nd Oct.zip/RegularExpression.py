import re

s = input('enter data :')

o = re.match('(.*) are (.*)',s)

if o:
    print('are is present ')
    print(o.groups())
    
else:
    print('not match ')

#search
email =input('enter email id :')
o = re.search('@gmail.com$',email)

if o:
    print('valid email id')
else:
    print('invalid email id')


    


    




