def add(a,b):
    print(a+b)

def tax(amt):
    t = amt*.10

    return t
