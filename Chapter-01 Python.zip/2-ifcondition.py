#WAP to take input as amt from user and show total amt including tax

amt = int(input('enter amt '))

t =0
if amt>1000:
    t = amt*.18


#total
t = amt+t
print(t)
