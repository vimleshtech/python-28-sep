#WAP to read data from user and show the addition

n1 = input('enter data ') #default input type is str
n2 = input('enter data ')

print(type(n1))
print(type(n2))

#type casting
n1= int(n1)
n2= int(n2)

n = n1+n2
print(n)


##

n1 =1
n2 =2
n =n1+n2
print(n)
