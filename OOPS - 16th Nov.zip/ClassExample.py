class emp:

    def newemp(s):
        s.eid = int(input('enter eid :'))
        s.ename = input('enter name :')
        s.bsal = int(input('enter bsal :'))


    def compute(a):
        hra = a.bsal*.40 #hra is local variable (within function)
        da = a.bsal*.40
        a.msal = a.bsal+hra+da #a.msal is gloabl variable (anywhere in class)
        a.ysal = a.msal*12
        a.tax = a.ysal*a.ts
        


    def __init__(self,country):
        print('object is created ')
        if country=='india':
            self.ts = .30
        else:
            self.ts = .45

    def __del__(s):
        print(s,'is deleted')
            
        
    def show(a):
        print('eid ',a.eid)
        print('name ',a.ename)
        print('msla ',a.msal)
        print('ysal ',a.ysal)
        
              


#create object of class emp 
o  = emp('us')
print(o) #<__main__.emp object at 0x035C63B0> address of object

o.newemp()
o.compute()
o.show()

del o
#o.show()



        

    


