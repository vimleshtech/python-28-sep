import mysql.connector as con

c = con.connect(host='127.0.0.1',user='root',password='root',database='db100')

cur  = c.cursor() #create object to execute sql statement


def get_data():
    cur.execute('select * from tbluser')

    data = cur.fetchall() #get data 

    #print(data)
    for r in data:
        print(r[0],r[1])
    


    
def save_data():
    cur.execute("insert into tbluser values({},'{}',{})".format(10,'rahul',55555))
    c.commit() #save data
    print('data is saved')


save_data()
get_data()

        
    

