#
i = 1
s =0
count = 0
while i<=100:
    if i%2==0 and i%3 ==0 and i%5 !=0:
        s =s+i
        count = count+1

    i = i+1

print(s)
print(s/count)



    
